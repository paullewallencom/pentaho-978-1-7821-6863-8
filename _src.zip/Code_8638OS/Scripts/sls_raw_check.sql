SELECT * FROM sls_raw.customer;
SELECT * FROM sls_raw.sales_channel;
SELECT * FROM sls_raw.lens_category;
SELECT * FROM sls_raw.lens;
SELECT * FROM sls_raw.sale;
