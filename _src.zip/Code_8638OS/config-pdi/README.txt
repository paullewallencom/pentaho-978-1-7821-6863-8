run the following on the command line:

source set-project-variables.sh

and only then start kettle spoon from the same shell.
It is best to add the contents of this file to your .bashrc or similar 
so that you do not have to set these variables each time before you start kettle
